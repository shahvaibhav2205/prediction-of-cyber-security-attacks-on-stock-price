/**
 * @author Kartik Kapadia
 */
package org.nytj4.core;

public class Headline {

	private String main;
	private String printHeadline;
	public String getMain() {
		return main;
	}
	public void setMain(String main) {
		this.main = main;
	}
	public String getPrintHeadline() {
		return printHeadline;
	}
	public void setPrintHeadline(String printHeadline) {
		this.printHeadline = printHeadline;
	}
	
	
	
	
}
