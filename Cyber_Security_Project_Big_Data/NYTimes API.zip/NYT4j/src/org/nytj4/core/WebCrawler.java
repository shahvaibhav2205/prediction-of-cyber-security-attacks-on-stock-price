package org.nytj4.core;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class WebCrawler {
	public static String crawl(String url) throws Exception{
		Document doc;
		System.out.println("url is: "+url);
		doc = Jsoup.connect(url).userAgent("Mozilla").get();
		String pConcatenated=doc.select("p").text();
		pConcatenated = pConcatenated.replaceAll("<[^>]*>", "");
		return pConcatenated;
	}
	public static void main(String[] args) throws Exception {

		String io = crawl("http://www.nytimes.com/2014/12/20/arts/the-disconnect-of-the-interview.html");
		System.out.println(io);

	}
}
