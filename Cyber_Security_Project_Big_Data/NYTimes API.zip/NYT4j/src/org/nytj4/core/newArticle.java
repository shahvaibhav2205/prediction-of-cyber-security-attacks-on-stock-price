package org.nytj4.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class newArticle {
	public static void createFile(String company,String date_format, String articleName, String body){
		try{
			if(!body.trim().isEmpty()){
				String path = company + "/" + date_format + "/" + articleName;
				
				File file = new File(path);
				int i =  2;
				while(file.exists() || file.isDirectory()){
	
	
					articleName = "nyarticle"+i;
	
					path = company + "/" + date_format + "/" + articleName;
					file = new File(path);
					i++;
				}
				System.out.println("file path to : "+path);
				System.out.println("----------------------------------------------------------------");
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(file,"UTF-8");
				writer.print(body);
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void updatelogfile(String company, String logfilename, String body){
		try{
			if(!body.trim().isEmpty()){

				String path = company +"_log/" + logfilename;
				
				File file = new File(path);
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
				body = body.substring(body.indexOf("/")+1, body.lastIndexOf("/"));
				writer.println(body);
				
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		//		System.out.println(test.toDate(2457004));
		
	}
}
