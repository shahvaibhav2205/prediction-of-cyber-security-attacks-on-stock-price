Run the ArticleSearchQueryImpl file's main method to generate articles using NewYork Times API.
Include all the files related to this project in same directory and then compile this file.

Compile: javac ArticleSearchQueryImpl.java

This file takes following arguments:
company name (If the company name contains space, then replace space with '+' character or '%20' character)
begin date (yyyymmdd)
end date (yyyymmdd)


Running the code:
Example: java ArticleSearchQueryImpl sony 20141101 20150101 

The above code will get the article data for sony in the date range 1 Nov 2014 to 1 Jan 2015 and store the data in a folder of company name inside the current directory.
