package webCrawler;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class newArticle {
	public static int flag = 0;
	public static void createFile(String company,long date, String articleName, String body){
		try{
			if(!body.trim().isEmpty()){
				String date_format = ""+dateConvert.toDate(date);
				System.out.println("date : "+date_format);
				String path = company + "/" + date_format + "/" + articleName;
				
				File file = new File(path);
				int i =  2;
				while(file.exists() || file.isDirectory()){
	
	
					articleName = "article"+i;
	
					path = company + "/" + date_format + "/" + articleName;
					file = new File(path);
					i++;
				}
				System.out.println("file path to : "+path);
				System.out.println("----------------------------------------------------------------");
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(file,"UTF-8");
				writer.print(body);
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void updatefile(String company,long date, String articleName, String body){
		try{
			if(!body.trim().isEmpty()){
				String date_format = ""+dateConvert.toDate(date);
				System.out.println("date : "+date_format);
				String path = company + "/" + date_format + "/" + articleName;
				
				File file = new File(path);
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
				writer.println(body);
				
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void updatefile(String company, String logfilename, String body, String name){
		try{
			if(!body.trim().isEmpty()){

				String path = company +"/" + logfilename;
				
				File file = new File(path);
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
				writer.println(name+","+body);
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void updatefile(String company, String logfilename, String body){
		try{
			if(!body.trim().isEmpty()){

				String path = company +"/" + logfilename;
				
				File file = new File(path);
				file.getParentFile().mkdirs();
				PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file, true)));
				writer.println(body);
				writer.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		//		System.out.println(test.toDate(2457004));
//		System.out.println(dateConvert.toDate(2456956));
//				updatefile("tpp", 2456723, "article1", "scscgg");
	}
}
