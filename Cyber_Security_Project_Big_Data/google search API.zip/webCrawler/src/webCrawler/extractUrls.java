package webCrawler;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;


public class extractUrls {
	
	public static void main(String[] args) {
		try {
			String fromDate = "2014-12-06";
			String toDate = "2014-12-07";
			int pages = 31;
			String company = "The%20Home%20Depot";
			//	    inputString2 = myFormat.format(new Date());

			long fromJulian = dateConvert.toJulian(fromDate);
			long toJulian =  dateConvert.toJulian(toDate);
			System.out.println(fromJulian+" "+toJulian);
			for(long i = fromJulian;i<toJulian;i++){
				Thread.sleep(1000);
				//				System.out.println(i);
				for(int page = 0;page<pages;page+=8){
					String query = "https://ajax.googleapis.com/ajax/services/search/web?q="+company+"+daterange%3A"+i+"-"+i+"&rsz=8&v=1.0&start="+page;
//					System.out.println(query);
					URL url = new URL(query);
					URLConnection connection = url.openConnection();
					connection.addRequestProperty("Referer", "www.google.com");
					String line;
					StringBuilder builder = new StringBuilder();
					BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
					while((line = reader.readLine()) != null) {
						builder.append(line);
					}
					webcrawler webc = new webcrawler();
					JSONObject json = new JSONObject(builder.toString());
					//							System.out.println(json.toString(4));
					JSONObject responseData = (JSONObject)json.get("responseData");
					JSONArray results = (JSONArray)responseData.get("results");
					for(int j = 0; j < results.length(); j++){
						String link = results.getJSONObject(j).getString("unescapedUrl");
						if(!(link.contains("www.youtube.com") || link.contains("www.amazon.com"))){
							System.out.println(link);
						}
					}
					//					System.out.println(results.toString(4));
				}
				System.out.println();
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
