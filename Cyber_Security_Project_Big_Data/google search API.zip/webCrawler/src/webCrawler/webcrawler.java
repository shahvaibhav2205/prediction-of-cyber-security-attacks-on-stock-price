package webCrawler;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class webcrawler {
	public static String crawl(String url){
		Document doc;
		String io = "";
		try {
			doc = Jsoup.connect(url).userAgent("Mozilla").get();
			io = doc.body().text();


		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return io;
	}
	public static String pcrawl(String url){
		Document doc;
		String io = "";
		try {
			doc = Jsoup.connect(url).userAgent("Mozilla").get();
//			Elements p= doc.getElementsByTag("p");

			String pConcatenated=doc.select("p").text();
			pConcatenated = pConcatenated.replaceAll("<[^>]*>", "");
//			System.out.println(pConcatenated);
			io = pConcatenated;
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return io;
	}
	
	public static void main(String[] args) throws IOException {

		String url = "http://www.yelp.com/biz/tanoshii-ramen-dallas";
		String io = pcrawl(url);
//		System.out.println(io);
//		newArticle.createFile("articles", 24252012, "article1", io);
		 

	}
}
