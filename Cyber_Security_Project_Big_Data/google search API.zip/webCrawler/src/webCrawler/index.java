package webCrawler;

public class index {
	public static void main(String[] args) {
		readingUrls.readUrls("companyURLs/home depot urls", "2014-10-06", "home depot/data");
	}
}
