package webCrawler;

import java.io.RandomAccessFile;
import java.util.HashMap;

public class dataCleaning {
	public static String clean(String body) {
		String newBody = "";
		try{
		Stemmer st = new Stemmer();
		HashMap<String, Integer> hash = initializeHash();
		String[] strArr = body.split("\\s");
		for (String i : strArr) {
			
			i = i.toLowerCase();
			i = i.replaceAll("[^a-zA-Z]+", "");
//			i = i.replaceAll(" ", "");
			i = i.trim();
			if(!hash.containsKey(i)){
//				System.out.println("Working on: '"+i+"'");
				i = st.stem(i);
				if(!i.equals("")){
					newBody += i + " ";
//					System.out.println("Worked as: "+i);
				}
			}
		}
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return newBody;
	}

	static public HashMap<String, Integer> initializeHash() throws Exception {
		HashMap<String, Integer> h = new HashMap<String, Integer>();
		RandomAccessFile Stop = null;
		try {
			Stop = new RandomAccessFile("stop_words.txt", "r");
		} catch (Exception e) {
			e.printStackTrace();
		}
		String s;
		while ((s = Stop.readLine()) != null) {
			h.put(s, 1);
		}
		return h;
	}
	//this function is just utility
	static public HashMap<Integer, Integer> testHash() throws Exception {
		HashMap<Integer, Integer> h = new HashMap<Integer, Integer>();
		RandomAccessFile Stop = null;
		try {
			Stop = new RandomAccessFile("dictionary/sony", "r");
		} catch (Exception e) {
			e.printStackTrace();
		}
		String s;
		while ((s = Stop.readLine()) != null) {
//			System.out.println(h.toString());
			String[] val = s.split("\\s");
			val[1] = val[1].trim();
//			System.out.println("working on : "+val[1]);
			if(h.containsKey(Integer.parseInt(val[1]))){
				h.put(Integer.parseInt(val[1]),h.get(Integer.parseInt(val[1]))+1);
			}
			else{
				h.put(Integer.parseInt(val[1]), 1);
			}
		}
		return h;
	}
	public static void main(String arg[]) throws Exception{
//		String sample = "Anyone buy this? If so, what'd you think?    Also, did you happen to compare it to either the iBasso DX50 or the Sony Xperia Z3 (smartphone)? If so, how did it fare??     Thank You,      RockStar2005 radiomann,    Thanks for your post!    So would you say it sounded noticeably BETTER than your X3, or the same?    With regards to your last sentence, which devices are you referring to? Did you happen to pit the A17 against the X5, or the iBasso DX90, or another player? If so, please provide details. What about compared to your phone's audio (please list the phone you have too)?    I have the Sony Xperia Z3 and tried out the iBasso DX50 last night vs my Z3, and to me they were pretty much identical. I couldn't say the DX50 was any better, despite being $200 (and at most only $40 went into my Z3's audio equipment, and that's considered high-end for android smartphones lol). The DX50 is going back. I want to know if ppl who tried other devices around $200 ($200-$350) noticed a difference vs either my Z3 or the DX50. That's why I ask. I just wonder, if at $200 I couldn't notice a difference, would I at around $300?    Thank You,    RockStar2005 cel,    Thanks for your input! Yeah I had the same impression regarding the X3 vs the DX50.    That is true too. Good ampage is important.    I actually bought the DX50 and compared it to my phone (Z3) using Sony MDR-1A headphones. After listening to several of the same songs on both, my opinion is they both sounded the same really, so I returned the DX50, and I just bought the Sony Walkman (NWZ-A17) from Amazon. It will come in by Wed. It has better specs and is $100 more, so I'm hoping I'll notice more of a difference as I don't want to spend any more than $300. If not, it'll go back too and that's that, but I'm hoping it does sound better than my phone. I guess that says something about my phone that it measured up to at least a $200 (DX50) stand-alone player. lol   Thanks,   RockStar2005 cel,    Sure....... will do! Prob this weekend or next week sometime.      RockStar2005 I got one a few weeks ago from amazon.  Got some mdr-1r's to go with them.   No way I'm going to take my home cans out in the wild.  The A17 has a very easy to use interface as my thumb has mastered the buttons already.  My oppo pm-1's sound great out of it, which surprised me.  They will get quite loud with very good sound quality with all my wav and flac files.   (44/16 and up to 96/24 with a few 192/24).  I don't use mp3's so can't report on them.    I must admit I'm very surprised as to how good it sounds.  The digital section is superb.  Don't know what power ratings it has, maybe some one can find out.   Just some thoughts on the A17 dap from a rookie.   Hey raptor,    Thanks so much for the post! I appreciate the info/review on the A17! Glad you were so happy with how it sounded (and the loud volume thing too ftw lol)!    I get mine tomorrow (Wed) from Amazon, so will need a lil time to review it, but it sounds like it's gonna (hopefully) be the one player to out-do my Sony Xperia Z3 phone. The easy interface I expected, though I'm still happy to hear someone else confirm it. The looks seem nice too (even though it's not metal lol). The main goal, or what I would consider to be a successful outcome, is that they sound NOTICEABLY better than my Z3. The A17 is $100 more than the iBasso DX50 I just returned, so I'm hoping that extra $100 yields the difference I'm looking for.   The main thing I'd really love is to hear someone say is that the A17 really cuts down or eliminates that damn background/tape hiss sound you get when you jack up the volume. Any opinion on that (anyone else who has an A17, feel free to chime in too!)??   RockStar2005 Hey raptor,    Thanks so much for the post! I appreciate the info/review on the A17! Glad you were so happy with how it sounded (and the loud volume thing too ftw lol)!    I get mine tomorrow (Wed) from Amazon, so will need a lil time to review it, but it sounds like it's gonna (hopefully) be the one player to out-do my Sony Xperia Z3 phone. The easy interface I expected, though I'm still happy to hear someone else confirm it. The looks seem nice too (even though it's not metal lol). The main goal, or what I would consider to be a successful outcome, is that they sound NOTICEABLY better than my Z3. The A17 is $100 more than the iBasso DX50 I just returned, so I'm hoping that extra $100 yields the difference I'm looking for.   The main thing I'd really love is to hear someone say is that the A17 really cuts down or eliminates that damn sound you get when you jack up the volume. Any opinion on that (anyone else who has an A17, feel free to chime in too!)??   RockStar2005 Just tried a full volume check and heard nothing but silence.   The volume bar was all the way to 30 and 15 on the volume scale is loud when music is playing.   Sony documentation on the A17 doesn't give signal to noise ratio figures, at least I haven't found any.      I read somewhere that the face plate is metal and the back case is plastic. Thanks for your input radiomann! Much appreciated!!    RockStar2005 Hey cel, raptor, and radioman   RockStar2005";
//		String sam = "t year, an alleged culprit behind the latter attributes:   Notice: It";
//		System.out.println(clean(sample));
		System.out.println(testHash().toString());
	}
}
