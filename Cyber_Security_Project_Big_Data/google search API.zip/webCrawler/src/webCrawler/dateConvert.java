package webCrawler;

import java.text.SimpleDateFormat;
import java.util.Date;

public class dateConvert {
	public static long toJulian(String date){
		long Julian = -1;
		try {
			SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
			String inputString1 = "2000-01-01";
			//	    inputString2 = myFormat.format(new Date());
			Date date1 = myFormat.parse(inputString1);
			Date D = myFormat.parse(date);
			long Diff = D.getTime() - date1.getTime();
			//			System.out.println("diff : "+(Diff/(1000*60*60)));
			//			long Days = TimeUnit.DAYS.convert(Diff, TimeUnit.MILLISECONDS);
			//			System.out.println((float)Diff/(1000*60*60*24));
			float intermediateValue = (float)Diff/(1000*60*60*24);
			intermediateValue += 0.5;
			long Days = (long) intermediateValue;
			//			System.out.println("days are : "+Days );
			Julian = 2451545 + Days;

		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Julian;
	}
	public static String toDate(long Julian){
		String date = "";
		long range = Julian - 2440587;
		//		System.out.println("days are : "+range);
		long secs = range*24*60*60*1000;
		Date test = new Date(secs);
		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd");
		date = myFormat.format(test);
		//		System.out.println(date);
		return date;
	}
}
