package webCrawler;

import java.awt.PageAttributes;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class readingUrls {
	@SuppressWarnings("static-access")
	public static void readUrls(String fileName, String startDate, String company){
		// The name of the file to open.
//		String fileName = "sample_url";
		long date = dateConvert.toJulian(startDate);
		int article_num = 1;
		// This will reference one line at a time
		String line = null;
		int url_count = 0;
		try {
			// FileReader reads text files in the default encoding.
			FileReader fileReader = 
					new FileReader(fileName);

			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = 
					new BufferedReader(fileReader);
			dataCleaning dc = new dataCleaning();
			ArrayList<String> urls = new ArrayList<String>();
			while((line = bufferedReader.readLine()) != null) {
				urls.add(line);
			}   
			
			for(String i : urls){
				System.out.println("At line : "+url_count);
				
				System.out.println(i);
				if(!i.trim().isEmpty()){
					url_count++;
					String body = webcrawler.crawl(i);
//					System.out.println(body);
					body = dc.clean(body);
					System.out.println("adding article : "+"article"+article_num+ " at date : "+date+" to : "+company);
					
					newArticle.createFile(company, date, "article"+article_num, body);
					article_num++;
				}
				//            	else if(urls.get(i).trim().length() == 7){
				//            		
				//            	}
				else{
					System.out.println("received a new line!");
					date++;
					url_count++;
					article_num =1;
				}
			}
			// Always close files.
			bufferedReader.close();   
			fileReader.close();
		}
		catch(FileNotFoundException ex) {
			System.out.println(
					"Unable to open file '" + 
							fileName + "'");                
		}
		catch(IOException ex) {
			System.out.println(
					"Error reading file '" 
							+ fileName + "'");                  
			// Or we could just do this: 
			// ex.printStackTrace();
		}
	}
	public static void main(String [] args) {


	}
}
